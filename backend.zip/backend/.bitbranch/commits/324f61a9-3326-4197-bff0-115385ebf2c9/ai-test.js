console.log('AI test')
